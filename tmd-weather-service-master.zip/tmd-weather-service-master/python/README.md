Python source codes for fetching WeatherToday and Weather3Hours data from the TMD.

# Required modules
* time
* threading
* datetime
* csv
* json
* urllib
* os
* collections
