<?php
// local
define('DB_HOST','localhost');
define('DB_USER', 'root');
define('DB_PASSWORD', 'rootroot');
define('DB_DB', 'gi_weather_data');
define('DB_TYPE', 'mysql');

define('SHOW_UPLOAD_TIME', false);
?>