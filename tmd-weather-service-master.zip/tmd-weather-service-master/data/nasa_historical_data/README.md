# NASA Historical data
* This directory contains histogrical data (1985-...) collected from NASA of each weather station in Thailand
* The cooridinates of each weather stations are provided by TMD : http://data.tmd.go.th/api/Station/v1/?uid=demo&ukey=demokey
* If the station has no WMO-ID or has invalid coordinates, it will not be recorded.
* For more information : https://power.larc.nasa.gov/docs/v1/
* The data : "T2M_MIN", "T2M_MAX", "PRECTOT", "CLRSKY_SFC_SW_DWN", "RH2M"
