# Historical weather data from TMD
* Range : 1986 - August 9, 2018
* Regions : North, North East, Central and Chanthaburi
